Just a port of my nexus mod to Thunderstore. 

DISREGARD FILEMOVEMENT; THIS UPDATE FIXES THAT