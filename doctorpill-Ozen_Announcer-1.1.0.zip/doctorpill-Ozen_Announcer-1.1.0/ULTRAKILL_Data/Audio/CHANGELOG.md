### v1.1.0
- Fixed files needing to be moved in order to work
